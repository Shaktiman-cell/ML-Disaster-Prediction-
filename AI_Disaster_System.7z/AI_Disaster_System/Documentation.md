python
# AI-Based Disaster Prediction & Management System

## Project Overview
Complete disaster prediction system using real government data (1900-2024) with machine learning models and interactive dashboard.

## Technologies Used
- Python 3.8+
- Flask (Backend API)
- Streamlit (Dashboard)
- Random Forest & XGBoost (ML Models)
- Real Kaggle Disaster Dataset

## Project Structure
AI_Disaster_System/
├── data/
│ ├── raw/ # Original CSV data
│ └── processed/ # Cleaned & processed data
├── models/ # Trained ML models
├── backend/
│ └── app.py # Flask API server
├── frontend/
│ └── dashboard.py # Streamlit dashboard
├── data_explorer.py # Data exploration
├── data_preprocessing.py # Data cleaning
├── model_training.py # ML model training
└── requirements.txt

text

## Installation & Setup

1. Clone repository and create virtual environment:
python -m venv venv
venv\Scripts\activate # Windows
source venv/bin/activate # Linux/Mac

text

2. Install dependencies:
pip install -r requirements.txt

text

3. Download dataset from: https://www.kaggle.com/datasets/victoraesthete/indian-disaster-dataset
   Place in: `data/raw/indian_disaster_data.csv`

4. Run data preprocessing:
python data_preprocessing.py

text

5. Train ML models:
python model_training.py

text

6. Start Flask API (keep running):
python backend/app.py

text

7. Start dashboard (new terminal):
streamlit run frontend/dashboard.py

text

## Usage
1. Open dashboard: http://localhost:8501
2. Select date, location, disaster type, magnitude
3. Click "Predict Risk Level"
4. View predictions, confidence, alerts
5. Check prediction history

## Model Performance
- Random Forest Accuracy: 46.5%
- XGBoost Accuracy: 41.4%
- Dataset: 783 disaster records (1900-2024)
- Features: 14 engineered features

## API Endpoints
- GET / - API info
- GET /health - Health check
- POST /predict - Single prediction
- POST /batch_predict - Multiple predictions
- GET /disaster_types - Available disaster types

## Features
- Real government disaster data
- Machine learning predictions
- Interactive web dashboard
- Risk level classification (LOW/MEDIUM/HIGH)
- Historical trend analysis
- Alert system
- Multiple Indian cities support

## Future Enhancements
- Real-time weather API integration
- SMS/Email alerts
- Mobile app
- Improved model accuracy
- Database storage
- Multi-language support

## Author
Your Name - Shalendra Tiwari
Built for academic/research purposes   YA KEH SAKTE HO COOL LAG RHA THA BS 
