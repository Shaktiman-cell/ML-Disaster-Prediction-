#"data manipulation h bs "
"""
Data Preprocessing for Disaster Prediction
Cleans and prepares data for ML model training
"""

import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder
from datetime import datetime

def load_and_clean_data(filepath='data/raw/indian_disaster_data.csv'):
    """
    Load and clean the disaster dataset
    """
    print("Loading data...")
    df = pd.read_csv(filepath)
    print(f"Original data: {df.shape[0]} rows, {df.shape[1]} columns")
    
    # Select relevant columns for disaster prediction
    columns_to_keep = [
        'Start Year', 'Start Month', 'Start Day',
        'Disaster Type', 'Disaster Subtype',
        'Latitude', 'Longitude',
        'Total Deaths', 'No. Injured', 'No. Affected',
        'Total Affected', 'Total Damage (\'000 US$)',
        'Magnitude', 'Region', 'Location'
    ]
    
    df_cleaned = df[columns_to_keep].copy()
    
    # Rename columns for easier access
    df_cleaned.columns = [
        'year', 'month', 'day',
        'disaster_type', 'disaster_subtype',
        'latitude', 'longitude',
        'deaths', 'injured', 'affected',
        'total_affected', 'damage_cost',
        'magnitude', 'region', 'location'
    ]
    
    print(f"\nCleaned data: {df_cleaned.shape[0]} rows, {df_cleaned.shape[1]} columns")
    
    return df_cleaned

def handle_missing_values(df):
    """
    Handle missing values intelligently
    """
    print("\nHandling missing values...")
    
    # Fill missing months with mode (most common month for disasters in India: July-August monsoon)
    df['month'] = df['month'].fillna(7)
    df['day'] = df['day'].fillna(15)
    
    # Fill missing coordinates with India's center coordinates
    df['latitude'] = df['latitude'].fillna(20.5937)
    df['longitude'] = df['longitude'].fillna(78.9629)
    
    # Fill missing numeric values with 0 (no data = no impact)
    numeric_cols = ['deaths', 'injured', 'affected', 'total_affected', 'damage_cost', 'magnitude']
    for col in numeric_cols:
        df[col] = df[col].fillna(0)
    
    # Fill missing categorical values
    df['disaster_subtype'] = df['disaster_subtype'].fillna('Unknown')
    df['region'] = df['region'].fillna('Unknown')
    df['location'] = df['location'].fillna('Unknown')
    
    print(f"Missing values after cleaning: {df.isnull().sum().sum()}")
    
    return df

def create_risk_level(df):
    """
    Create risk level labels based on impact metrics
    Risk levels: LOW, MEDIUM, HIGH
    """
    print("\nCreating risk level labels...")
    
    # Calculate composite impact score
    df['impact_score'] = (
        df['deaths'] * 10 +  # Deaths weighted heavily
        df['injured'] * 5 +
        df['total_affected'] / 1000 +
        df['damage_cost'] / 100000
    )
    
    # Define risk levels based on percentiles
    percentile_33 = df['impact_score'].quantile(0.33)
    percentile_66 = df['impact_score'].quantile(0.66)
    
    def assign_risk(score):
        if score <= percentile_33:
            return 'LOW'
        elif score <= percentile_66:
            return 'MEDIUM'
        else:
            return 'HIGH'
    
    df['risk_level'] = df['impact_score'].apply(assign_risk)
    
    print("\nRisk level distribution:")
    print(df['risk_level'].value_counts())
    
    return df

def create_features(df):
    """
    Create additional features for better predictions
    """
    print("\nCreating additional features...")
    
    # Time-based features
    df['is_monsoon'] = df['month'].apply(lambda x: 1 if x in [6, 7, 8, 9] else 0)
    df['is_winter'] = df['month'].apply(lambda x: 1 if x in [12, 1, 2] else 0)
    df['is_summer'] = df['month'].apply(lambda x: 1 if x in [3, 4, 5] else 0)
    
    # Disaster frequency by type
    disaster_freq = df['disaster_type'].value_counts().to_dict()
    df['disaster_frequency'] = df['disaster_type'].map(disaster_freq)
    
    # Geographic risk zones
    # North India: latitude > 28
    # Central India: 20 < latitude <= 28
    # South India: latitude <= 20
    df['geo_zone'] = pd.cut(df['latitude'], 
                            bins=[0, 20, 28, 40], 
                            labels=['South', 'Central', 'North'])
    
    return df

def encode_categorical(df):
    """
    Encode categorical variables for ML
    """
    print("\nEncoding categorical variables...")
    
    # Label encoding for categorical columns
    le_disaster = LabelEncoder()
    le_subtype = LabelEncoder()
    le_region = LabelEncoder()
    le_zone = LabelEncoder()
    
    df['disaster_type_encoded'] = le_disaster.fit_transform(df['disaster_type'])
    df['disaster_subtype_encoded'] = le_subtype.fit_transform(df['disaster_subtype'])
    df['region_encoded'] = le_region.fit_transform(df['region'])
    df['geo_zone_encoded'] = le_zone.fit_transform(df['geo_zone'].astype(str))
    
    # Save encoders for later use
    encoders = {
        'disaster_type': le_disaster,
        'disaster_subtype': le_subtype,
        'region': le_region,
        'geo_zone': le_zone
    }
    
    return df, encoders

def prepare_ml_dataset(df):
    """
    Prepare final dataset for ML training
    """
    print("\nPreparing ML dataset...")
    
    # Select features for ML model
    feature_columns = [
        'year', 'month', 'day',
        'latitude', 'longitude',
        'magnitude', 'disaster_frequency',
        'is_monsoon', 'is_winter', 'is_summer',
        'disaster_type_encoded', 'disaster_subtype_encoded',
        'region_encoded', 'geo_zone_encoded'
    ]
    
    target_column = 'risk_level'
    
    X = df[feature_columns].copy()
    y = df[target_column].copy()
    
    print(f"\nFeatures shape: {X.shape}")
    print(f"Target shape: {y.shape}")
    print(f"\nFeature columns: {feature_columns}")
    
    return X, y, df

def save_processed_data(df, X, y, encoders):
    """
    Save processed data and encoders
    """
    print("\nSaving processed data...")
    
    # Save full processed dataframe
    df.to_csv('data/processed/disaster_data_processed.csv', index=False)
    print("Saved: data/processed/disaster_data_processed.csv")
    
    # Save features and target
    X.to_csv('data/processed/features.csv', index=False)
    y.to_csv('data/processed/target.csv', index=False)
    print("Saved: data/processed/features.csv")
    print("Saved: data/processed/target.csv")
    
    # Save encoders
    import joblib
    joblib.dump(encoders, 'data/processed/encoders.pkl')
    print("Saved: data/processed/encoders.pkl")

if __name__ == "__main__":
    print("="*60)
    print("DATA PREPROCESSING FOR DISASTER PREDICTION")
    print("="*60)
    
    # Load and clean
    df = load_and_clean_data()
    
    # Handle missing values
    df = handle_missing_values(df)
    
    # Create risk levels
    df = create_risk_level(df)
    
    # Create features
    df = create_features(df)
    
    # Encode categorical
    df, encoders = encode_categorical(df)
    
    # Prepare ML dataset
    X, y, df = prepare_ml_dataset(df)
    
    # Save everything
    save_processed_data(df, X, y, encoders)
    
    print("\n" + "="*60)
    print("DATA PREPROCESSING COMPLETE!")
    print("="*60)
    print("\nNext step: Train ML model using the processed data")
