"""
Data Explorer - Real Disaster Data Analysis
Explores Indian Disaster Dataset
"""

import pandas as pd
import numpy as np
from datetime import datetime

def load_disaster_data(filepath='data/raw/indian_disaster_data.csv'):
    """
    Load real disaster data from CSV with robust column detection
    """
    try:
        print("Loading data from:", filepath)
        df = pd.read_csv(filepath)
        print("Data loaded successfully!")
        print("Total records:", len(df))
        
        # Print all columns to see what we have
        print("\nAvailable columns:")
        print(df.columns.tolist())
        
        # Try to find year information
        # First check if there's a column with 'year' in the name
        year_cols = [col for col in df.columns if 'year' in col.lower()]
        
        if year_cols:
            year_col = year_cols[0]
            print(f"\nFound year column: {year_col}")
            try:
                year_min = df[year_col].min()
                year_max = df[year_col].max()
                print(f"Date range: {year_min} to {year_max}")
            except:
                print("Could not extract year range")
        else:
            # Try to find date columns
            date_cols = [col for col in df.columns if any(word in col.lower() for word in ['date', 'time', 'start', 'began'])]
            if date_cols:
                date_col = date_cols[0]
                print(f"\nFound date column: {date_col}")
                try:
                    df[date_col] = pd.to_datetime(df[date_col], errors='coerce')
                    df['Year'] = df[date_col].dt.year
                    year_min = df['Year'].min()
                    year_max = df['Year'].max()
                    print(f"Date range extracted: {year_min} to {year_max}")
                except:
                    print("Could not extract year from date column")
            else:
                print("\nNo year or date column found")
        
        return df
        
    except FileNotFoundError:
        print("ERROR: File not found!")
        print("Please download from: https://www.kaggle.com/datasets/victoraesthete/indian-disaster-dataset")
        return None
    except Exception as e:
        print(f"ERROR loading data: {e}")
        return None

def explore_data(df):
    """
    Explore the dataset structure
    """
    if df is None:
        return
    
    print("\n" + "="*60)
    print("DATA EXPLORATION")
    print("="*60)
    
    # Basic info
    print("\nDataset Info:")
    print(f"Shape: {df.shape}")
    print(f"Columns: {len(df.columns)}")
    print(f"Rows: {len(df)}")
    
    # Column names and types
    print("\nColumn Names and Types:")
    for col in df.columns:
        print(f"  {col}: {df[col].dtype}")
    
    # First few rows
    print("\nFirst 5 rows:")
    print(df.head())
    
    # Check for disaster type column
    disaster_cols = [col for col in df.columns if 'disaster' in col.lower() or 'type' in col.lower() or 'event' in col.lower()]
    if disaster_cols:
        disaster_col = disaster_cols[0]
        print(f"\nDisaster Types (from column '{disaster_col}'):")
        print(df[disaster_col].value_counts())
    
    # Missing values
    print("\nMissing Values:")
    missing = df.isnull().sum()
    if missing.sum() > 0:
        print(missing[missing > 0])
    else:
        print("No missing values")
    
    # Numeric statistics
    print("\nNumeric Columns Statistics:")
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    if len(numeric_cols) > 0:
        print(df[numeric_cols].describe())
    else:
        print("No numeric columns found")

def save_exploration_report(df):
    """
    Save exploration report to file
    """
    if df is None:
        return
    
    report_path = 'data/data_exploration_report.txt'
    
    with open(report_path, 'w') as f:
        f.write("Data Exploration Report\n")
        f.write(f"Generated: {datetime.now()}\n")
        f.write("="*60 + "\n\n")
        
        f.write(f"Total Records: {len(df)}\n")
        f.write(f"Total Columns: {len(df.columns)}\n\n")
        
        f.write("Column Names:\n")
        for col in df.columns:
            f.write(f"  - {col} ({df[col].dtype})\n")
        
        f.write("\nFirst 10 rows:\n")
        f.write(df.head(10).to_string())
        
    print(f"\nReport saved to: {report_path}")

if __name__ == "__main__":
    print("REAL DISASTER DATA EXPLORER")
    print("="*60)
    
    # Load data
    df = load_disaster_data()
    
    # Explore
    if df is not None:
        explore_data(df)
        save_exploration_report(df)
        print("\nExploration complete!")
    else:
        print("\nFailed to load data. Please check the file path.")
