"""
Streamlit Dashboard for Disaster Prediction System
Real-time visualization and prediction interface
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import requests
from datetime import datetime
import time

# Page config
st.set_page_config(
    page_title="Disaster Prediction Dashboard",
    page_icon="🌍",
    layout="wide"
)

# API endpoint
API_URL = "http://localhost:5000"

# Custom CSS
st.markdown("""
    <style>
    .main-header {
        font-size: 2.5rem;
        color: #1f77b4;
        text-align: center;
        margin-bottom: 1rem;
    }
    .stAlert {
        padding: 1rem;
        border-radius: 0.5rem;
    }
    </style>
""", unsafe_allow_html=True)

def check_api_health():
    """Check if API is running"""
    try:
        response = requests.get(f"{API_URL}/health", timeout=2)
        return response.status_code == 200
    except:
        return False

def get_disaster_types():
    """Get available disaster types from API"""
    try:
        response = requests.get(f"{API_URL}/disaster_types", timeout=5)
        if response.status_code == 200:
            data = response.json()
            return data.get('disaster_types', [])
        return []
    except:
        return []

def make_prediction(input_data):
    """Call API for prediction"""
    try:
        response = requests.post(
            f"{API_URL}/predict",
            json=input_data,
            timeout=10
        )
        if response.status_code == 200:
            return response.json()
        else:
            return {'error': f'API returned status {response.status_code}'}
    except Exception as e:
        return {'error': str(e)}

def create_gauge_chart(value, title, max_value):
    """Create gauge chart for confidence"""
    fig = go.Figure(go.Indicator(
        mode="gauge+number",
        value=value,
        title={'text': title},
        gauge={
            'axis': {'range': [None, max_value]},
            'bar': {'color': "darkblue"},
            'steps': [
                {'range': [0, 33], 'color': "lightgreen"},
                {'range': [33, 66], 'color': "yellow"},
                {'range': [66, 100], 'color': "lightcoral"}
            ],
            'threshold': {
                'line': {'color': "red", 'width': 4},
                'thickness': 0.75,
                'value': 90
            }
        }
    ))
    fig.update_layout(height=250, margin=dict(l=20, r=20, t=50, b=20))
    return fig

def create_probability_chart(probabilities):
    """Create bar chart for class probabilities"""
    df = pd.DataFrame({
        'Risk Level': list(probabilities.keys()),
        'Probability (%)': list(probabilities.values())
    })
    
    fig = px.bar(
        df,
        x='Risk Level',
        y='Probability (%)',
        title='Risk Level Probabilities',
        color='Risk Level',
        color_discrete_map={'LOW': 'green', 'MEDIUM': 'orange', 'HIGH': 'red'}
    )
    fig.update_layout(height=300, showlegend=False)
    return fig

# Main app
st.markdown('<h1 class="main-header">Disaster Prediction & Management System</h1>', 
            unsafe_allow_html=True)

# Check API status
api_status = check_api_health()

if not api_status:
    st.error("⚠️ API Server is not running!")
    st.info("Please start the Flask backend: `python backend/app.py`")
    st.stop()
else:
    st.success("✅ Connected to API Server")

# Sidebar
with st.sidebar:
    st.title("⚙️ Prediction Parameters")
    
    st.markdown("---")
    
    # Date inputs
    st.subheader("📅 Date Information")
    year = st.number_input("Year", min_value=2000, max_value=2030, value=2024)
    month = st.slider("Month", 1, 12, 7)
    day = st.slider("Day", 1, 31, 15)
    
    st.markdown("---")
    
    # Location inputs
    st.subheader("📍 Location")
    
    # Predefined locations
    locations = {
        "Custom": (0, 0),
        "Delhi": (28.6139, 77.2090),
        "Mumbai": (19.0760, 72.8777),
        "Kolkata": (22.5726, 88.3639),
        "Chennai": (13.0827, 80.2707),
        "Bangalore": (12.9716, 77.5946),
        "Hyderabad": (17.3850, 78.4867)
    }
    
    selected_location = st.selectbox("Select City", list(locations.keys()))
    
    if selected_location == "Custom":
        latitude = st.number_input("Latitude", min_value=-90.0, max_value=90.0, value=20.5937, step=0.1)
        longitude = st.number_input("Longitude", min_value=-180.0, max_value=180.0, value=78.9629, step=0.1)
    else:
        latitude, longitude = locations[selected_location]
        st.info(f"Lat: {latitude}, Lon: {longitude}")
    
    st.markdown("---")
    
    # Disaster parameters
    st.subheader("🌪️ Disaster Parameters")
    
    disaster_types = get_disaster_types()
    if disaster_types:
        disaster_type = st.selectbox("Disaster Type", disaster_types)
    else:
        disaster_type = st.text_input("Disaster Type", value="Flood")
    
    magnitude = st.slider("Magnitude/Intensity", 0.0, 10.0, 5.0, 0.1)
    
    st.markdown("---")
    
    # Predict button
    predict_button = st.button("🔮 Predict Risk Level", use_container_width=True)

# Main content
if predict_button:
    with st.spinner("Making prediction..."):
        # Prepare input data
        input_data = {
            'year': int(year),
            'month': int(month),
            'day': int(day),
            'latitude': float(latitude),
            'longitude': float(longitude),
            'magnitude': float(magnitude),
            'disaster_type': str(disaster_type)
        }
        
        # Get prediction
        result = make_prediction(input_data)
        
        if 'error' in result:
            st.error(f"❌ Error: {result['error']}")
        else:
            # Store in session state
            if 'predictions' not in st.session_state:
                st.session_state.predictions = []
            
            st.session_state.predictions.append({
                'timestamp': datetime.now(),
                'result': result,
                'input': input_data
            })
            
            # Display result
            risk_level = result['risk_level']
            confidence = result['confidence']
            
            # Risk level alert
            if risk_level == 'HIGH':
                st.error(f"🚨 HIGH RISK DETECTED (Confidence: {confidence}%)")
            elif risk_level == 'MEDIUM':
                st.warning(f"⚠️ MEDIUM RISK (Confidence: {confidence}%)")
            else:
                st.success(f"✅ LOW RISK (Confidence: {confidence}%)")
            
            # Metrics row
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Risk Level", risk_level)
            
            with col2:
                st.metric("Confidence", f"{confidence}%")
            
            with col3:
                st.metric("Location", selected_location)
            
            st.markdown("---")
            
            # Charts row
            col1, col2 = st.columns(2)
            
            with col1:
                # Confidence gauge
                gauge_fig = create_gauge_chart(confidence, "Prediction Confidence", 100)
                st.plotly_chart(gauge_fig, use_container_width=True)
            
            with col2:
                # Probability chart
                prob_fig = create_probability_chart(result['probabilities'])
                st.plotly_chart(prob_fig, use_container_width=True)
            
            st.markdown("---")
            
            # Alerts section
            st.subheader("📢 Alerts & Recommendations")
            for alert in result.get('alerts', []):
                st.info(alert)
            
            st.markdown("---")
            
            # Input details
            with st.expander("📋 View Input Details"):
                st.json(input_data)
            
            # Full response
            with st.expander("🔍 View Full API Response"):
                st.json(result)

# Prediction history
if 'predictions' in st.session_state and len(st.session_state.predictions) > 0:
    st.markdown("---")
    st.subheader("📊 Prediction History")
    
    # Create dataframe
    history_data = []
    for pred in st.session_state.predictions:
        history_data.append({
            'Timestamp': pred['timestamp'].strftime('%Y-%m-%d %H:%M:%S'),
            'Risk Level': pred['result']['risk_level'],
            'Confidence': f"{pred['result']['confidence']}%",
            'Location': f"({pred['input']['latitude']}, {pred['input']['longitude']})",
            'Magnitude': pred['input']['magnitude']
        })
    
    history_df = pd.DataFrame(history_data)
    st.dataframe(history_df, use_container_width=True)
    
    # Risk distribution
    risk_counts = history_df['Risk Level'].value_counts()
    if len(risk_counts) > 0:
        fig_pie = px.pie(
            values=risk_counts.values,
            names=risk_counts.index,
            title='Risk Level Distribution',
            color=risk_counts.index,
            color_discrete_map={'LOW': 'green', 'MEDIUM': 'orange', 'HIGH': 'red'}
        )
        st.plotly_chart(fig_pie, use_container_width=True)
    
    # Clear history button
    if st.button("🗑️ Clear History"):
        st.session_state.predictions = []
        st.rerun()

# Footer
st.markdown("---")
st.markdown("""
    <div style='text-align: center; color: #808080;'>
        <p>AI-Based Disaster Prediction System | Built with Streamlit, Flask & Machine Learning</p>
        <p>Using Real Government Disaster Data (1900-2024)</p>
    </div>
""", unsafe_allow_html=True)
