"""
ML Model Training for Disaster Prediction
Trains Random Forest and XGBoost models
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import xgboost as xgb
import joblib
import matplotlib.pyplot as plt
import seaborn as sns

def load_processed_data():
    """
    Load preprocessed features and target
    """
    print("Loading preprocessed data...")
    X = pd.read_csv('data/processed/features.csv')
    y = pd.read_csv('data/processed/target.csv').values.ravel()
    
    print(f"Features shape: {X.shape}")
    print(f"Target shape: {y.shape}")
    print(f"\nTarget distribution:")
    unique, counts = np.unique(y, return_counts=True)
    for label, count in zip(unique, counts):
        print(f"  {label}: {count}")
    
    return X, y

def split_data(X, y, test_size=0.2):
    """
    Split data into train and test sets
    """
    print(f"\nSplitting data (train: {int((1-test_size)*100)}%, test: {int(test_size*100)}%)...")
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=42, stratify=y
    )
    
    print(f"Training set: {X_train.shape[0]} samples")
    print(f"Test set: {X_test.shape[0]} samples")
    
    return X_train, X_test, y_train, y_test

def train_random_forest(X_train, y_train):
    """
    Train Random Forest classifier
    """
    print("\n" + "="*60)
    print("TRAINING RANDOM FOREST MODEL")
    print("="*60)
    
    rf_model = RandomForestClassifier(
        n_estimators=100,
        max_depth=15,
        min_samples_split=5,
        min_samples_leaf=2,
        random_state=42,
        n_jobs=-1
    )
    
    print("Training in progress...")
    rf_model.fit(X_train, y_train)
    print("Random Forest training complete!")
    
    return rf_model

def train_xgboost(X_train, y_train):
    """
    Train XGBoost classifier
    """
    print("\n" + "="*60)
    print("TRAINING XGBOOST MODEL")
    print("="*60)
    
    # Encode labels to numeric (XGBoost requirement)
    from sklearn.preprocessing import LabelEncoder
    le = LabelEncoder()
    y_train_encoded = le.fit_transform(y_train)
    
    xgb_model = xgb.XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        random_state=42,
        n_jobs=-1
    )
    
    print("Training in progress...")
    xgb_model.fit(X_train, y_train_encoded)
    print("XGBoost training complete!")
    
    return xgb_model, le

def evaluate_model(model, X_test, y_test, model_name="Model", label_encoder=None):
    """
    Evaluate model performance
    """
    print(f"\n{'='*60}")
    print(f"EVALUATING {model_name.upper()}")
    print("="*60)
    
    # Make predictions
    if label_encoder is not None:
        y_test_encoded = label_encoder.transform(y_test)
        y_pred = model.predict(X_test)
        y_pred_labels = label_encoder.inverse_transform(y_pred)
        y_test_labels = y_test
    else:
        y_pred_labels = model.predict(X_test)
        y_test_labels = y_test
    
    # Accuracy
    accuracy = accuracy_score(y_test_labels, y_pred_labels)
    print(f"\nAccuracy: {accuracy*100:.2f}%")
    
    # Classification report
    print(f"\nClassification Report:")
    print(classification_report(y_test_labels, y_pred_labels))
    
    # Confusion matrix
    print(f"\nConfusion Matrix:")
    cm = confusion_matrix(y_test_labels, y_pred_labels)
    print(cm)
    
    return accuracy, y_pred_labels

def feature_importance_analysis(model, feature_names, model_name="Model"):
    """
    Analyze and display feature importance
    """
    print(f"\n{'='*60}")
    print(f"FEATURE IMPORTANCE - {model_name.upper()}")
    print("="*60)
    
    importances = model.feature_importances_
    indices = np.argsort(importances)[::-1]
    
    print("\nTop 10 Most Important Features:")
    for i in range(min(10, len(indices))):
        idx = indices[i]
        print(f"{i+1}. {feature_names[idx]}: {importances[idx]:.4f}")
    
    return importances

def cross_validate_model(model, X, y, model_name="Model"):
    """
    Perform cross-validation
    """
    print(f"\n{'='*60}")
    print(f"CROSS-VALIDATION - {model_name.upper()}")
    print("="*60)
    
    scores = cross_val_score(model, X, y, cv=5, scoring='accuracy')
    
    print(f"\nCross-validation scores: {scores}")
    print(f"Mean accuracy: {scores.mean()*100:.2f}%")
    print(f"Standard deviation: {scores.std()*100:.2f}%")
    
    return scores

def save_models(rf_model, xgb_model, xgb_label_encoder):
    """
    Save trained models
    """
    print("\n" + "="*60)
    print("SAVING MODELS")
    print("="*60)
    
    # Save Random Forest
    joblib.dump(rf_model, 'models/random_forest_model.pkl')
    print("Saved: models/random_forest_model.pkl")
    
    # Save XGBoost
    joblib.dump(xgb_model, 'models/xgboost_model.pkl')
    print("Saved: models/xgboost_model.pkl")
    
    # Save XGBoost label encoder
    joblib.dump(xgb_label_encoder, 'models/xgb_label_encoder.pkl')
    print("Saved: models/xgb_label_encoder.pkl")

def compare_models(rf_accuracy, xgb_accuracy):
    """
    Compare model performances
    """
    print("\n" + "="*60)
    print("MODEL COMPARISON")
    print("="*60)
    
    print(f"\nRandom Forest Accuracy: {rf_accuracy*100:.2f}%")
    print(f"XGBoost Accuracy: {xgb_accuracy*100:.2f}%")
    
    if rf_accuracy > xgb_accuracy:
        print("\nBest Model: Random Forest")
        best_model = "Random Forest"
    elif xgb_accuracy > rf_accuracy:
        print("\nBest Model: XGBoost")
        best_model = "XGBoost"
    else:
        print("\nBoth models have equal accuracy")
        best_model = "Both"
    
    return best_model

if __name__ == "__main__":
    print("="*60)
    print("ML MODEL TRAINING FOR DISASTER PREDICTION")
    print("="*60)
    
    # Load data
    X, y = load_processed_data()
    
    # Split data
    X_train, X_test, y_train, y_test = split_data(X, y)
    
    # Train Random Forest
    rf_model = train_random_forest(X_train, y_train)
    rf_accuracy, rf_predictions = evaluate_model(rf_model, X_test, y_test, "Random Forest")
    rf_importances = feature_importance_analysis(rf_model, X.columns.tolist(), "Random Forest")
    
    # Train XGBoost
    xgb_model, xgb_le = train_xgboost(X_train, y_train)
    xgb_accuracy, xgb_predictions = evaluate_model(xgb_model, X_test, y_test, "XGBoost", xgb_le)
    xgb_importances = feature_importance_analysis(xgb_model, X.columns.tolist(), "XGBoost")
    
    # Cross-validation
    print("\n" + "="*60)
    print("CROSS-VALIDATION")
    print("="*60)
    rf_cv_scores = cross_validate_model(rf_model, X_train, y_train, "Random Forest")
    
    # Compare models
    best_model = compare_models(rf_accuracy, xgb_accuracy)
    
    # Save models
    save_models(rf_model, xgb_model, xgb_le)
    
    print("\n" + "="*60)
    print("MODEL TRAINING COMPLETE!")
    print("="*60)
    print(f"\nBest performing model: {best_model}")
    print("\nNext step: Build Flask API backend")
