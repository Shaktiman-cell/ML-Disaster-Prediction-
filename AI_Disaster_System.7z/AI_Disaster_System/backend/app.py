"""
Flask API Backend for Disaster Prediction System
Serves ML model predictions via REST API
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import joblib
import numpy as np
from datetime import datetime

app = Flask(__name__)
CORS(app)

# Global variables for models and encoders
rf_model = None
encoders = None

def load_models():
    """
    Load trained models and encoders
    """
    global rf_model, encoders
    
    try:
        rf_model = joblib.load('models/random_forest_model.pkl')
        encoders = joblib.load('data/processed/encoders.pkl')
        print("Models loaded successfully")
        return True
    except Exception as e:
        print(f"Error loading models: {e}")
        return False

def prepare_input_features(data):
    """
    Prepare input data for prediction
    """
    try:
        # Create feature dictionary
        features = {
            'year': data.get('year', 2024),
            'month': data.get('month', 1),
            'day': data.get('day', 1),
            'latitude': data.get('latitude', 20.5937),
            'longitude': data.get('longitude', 78.9629),
            'magnitude': data.get('magnitude', 0),
            'disaster_frequency': data.get('disaster_frequency', 100),
            'is_monsoon': 1 if data.get('month', 1) in [6, 7, 8, 9] else 0,
            'is_winter': 1 if data.get('month', 1) in [12, 1, 2] else 0,
            'is_summer': 1 if data.get('month', 1) in [3, 4, 5] else 0,
            'disaster_type_encoded': 0,
            'disaster_subtype_encoded': 0,
            'region_encoded': 0,
            'geo_zone_encoded': 0
        }
        
        # Encode disaster type if provided
        if 'disaster_type' in data and encoders is not None:
            try:
                features['disaster_type_encoded'] = encoders['disaster_type'].transform([data['disaster_type']])[0]
            except:
                features['disaster_type_encoded'] = 0
        
        # Determine geo zone from latitude
        lat = features['latitude']
        if lat <= 20:
            features['geo_zone_encoded'] = 0  # South
        elif lat <= 28:
            features['geo_zone_encoded'] = 1  # Central
        else:
            features['geo_zone_encoded'] = 2  # North
        
        # Convert to dataframe
        input_df = pd.DataFrame([features])
        
        return input_df
        
    except Exception as e:
        print(f"Error preparing features: {e}")
        return None

def get_risk_alerts(risk_level, data):
    """
    Generate alerts based on risk level and input parameters
    """
    alerts = []
    
    magnitude = data.get('magnitude', 0)
    month = data.get('month', 1)
    
    if risk_level == 'HIGH':
        alerts.append("HIGH RISK: Immediate action required")
        alerts.append("Alert authorities and emergency services")
        alerts.append("Evacuate vulnerable areas if necessary")
    elif risk_level == 'MEDIUM':
        alerts.append("MEDIUM RISK: Stay alert and monitor situation")
        alerts.append("Keep emergency supplies ready")
    else:
        alerts.append("LOW RISK: Normal monitoring sufficient")
    
    # Specific alerts based on parameters
    if magnitude > 5:
        alerts.append("High magnitude detected - potential for severe impact")
    
    if month in [6, 7, 8, 9]:
        alerts.append("Monsoon season - increased flood risk")
    
    return alerts

@app.route('/', methods=['GET'])
def home():
    """
    API home endpoint
    """
    return jsonify({
        'message': 'Disaster Prediction API',
        'version': '1.0',
        'status': 'running',
        'endpoints': {
            '/': 'API info',
            '/health': 'Health check',
            '/predict': 'POST - Disaster risk prediction',
            '/batch_predict': 'POST - Batch predictions'
        }
    })

@app.route('/health', methods=['GET'])
def health():
    """
    Health check endpoint
    """
    model_status = rf_model is not None
    encoders_status = encoders is not None
    
    return jsonify({
        'status': 'healthy' if (model_status and encoders_status) else 'unhealthy',
        'model_loaded': model_status,
        'encoders_loaded': encoders_status,
        'timestamp': datetime.now().isoformat()
    })

@app.route('/predict', methods=['POST'])
def predict():
    """
    Single prediction endpoint
    
    Expected JSON input:
    {
        "year": 2024,
        "month": 7,
        "day": 15,
        "latitude": 28.6139,
        "longitude": 77.2090,
        "magnitude": 5.5,
        "disaster_type": "Flood"
    }
    """
    try:
        # Get JSON data
        data = request.get_json()
        
        if not data:
            return jsonify({'error': 'No data provided'}), 400
        
        # Prepare features
        input_features = prepare_input_features(data)
        
        if input_features is None:
            return jsonify({'error': 'Failed to prepare input features'}), 500
        
        # Make prediction
        prediction = rf_model.predict(input_features)[0]
        probabilities = rf_model.predict_proba(input_features)[0]
        
        # Get class labels
        classes = rf_model.classes_
        prob_dict = {classes[i]: float(probabilities[i]) for i in range(len(classes))}
        
        # Get confidence
        confidence = float(max(probabilities)) * 100
        
        # Generate alerts
        alerts = get_risk_alerts(prediction, data)
        
        # Prepare response
        response = {
            'risk_level': prediction,
            'confidence': round(confidence, 2),
            'probabilities': {k: round(v*100, 2) for k, v in prob_dict.items()},
            'alerts': alerts,
            'input_data': data,
            'timestamp': datetime.now().isoformat()
        }
        
        return jsonify(response), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/batch_predict', methods=['POST'])
def batch_predict():
    """
    Batch prediction endpoint
    
    Expected JSON input:
    {
        "data": [
            {"year": 2024, "month": 7, ...},
            {"year": 2024, "month": 8, ...}
        ]
    }
    """
    try:
        request_data = request.get_json()
        
        if not request_data or 'data' not in request_data:
            return jsonify({'error': 'No data array provided'}), 400
        
        data_list = request_data['data']
        results = []
        
        for data in data_list:
            input_features = prepare_input_features(data)
            
            if input_features is not None:
                prediction = rf_model.predict(input_features)[0]
                probabilities = rf_model.predict_proba(input_features)[0]
                confidence = float(max(probabilities)) * 100
                
                results.append({
                    'risk_level': prediction,
                    'confidence': round(confidence, 2),
                    'input_data': data
                })
        
        return jsonify({
            'predictions': results,
            'count': len(results),
            'timestamp': datetime.now().isoformat()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/disaster_types', methods=['GET'])
def get_disaster_types():
    """
    Get available disaster types
    """
    if encoders is None:
        return jsonify({'error': 'Encoders not loaded'}), 500
    
    try:
        disaster_types = encoders['disaster_type'].classes_.tolist()
        return jsonify({
            'disaster_types': disaster_types,
            'count': len(disaster_types)
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    print("="*60)
    print("DISASTER PREDICTION API SERVER")
    print("="*60)
    
    # Load models
    if load_models():
        print("\nStarting Flask server...")
        print("API available at: http://localhost:5000")
        print("\nEndpoints:")
        print("  GET  /")
        print("  GET  /health")
        print("  POST /predict")
        print("  POST /batch_predict")
        print("  GET  /disaster_types")
        print("\n" + "="*60)
        
        app.run(host='0.0.0.0', port=5000, debug=True)
    else:
        print("\nERROR: Failed to load models")
        print("Please ensure model files exist in the 'models' directory")
